globalThis.__spotifyplus_worklet_bundle__ = 2;
"use strict";
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);

// src/index.ts
var import_spotifyplus = require("spotifyplus");

// src/model.ts
var DEFAULTS = [5, 10, 15, 30, 45, 60, 0];
var STORAGE_KEY = "sleep-timer-presets-v1";
function defaultConfiguration() {
  return {
    version: 1,
    presets: DEFAULTS.map((minutes) => ({
      key: minutes ? `default:${minutes}` : "default:end-of-content",
      defaultId: minutes ? `default:${minutes}` : "default:end-of-content",
      minutes
    }))
  };
}
function readConfiguration(value) {
  if (!value || typeof value !== "object") return defaultConfiguration();
  const config = value;
  if (config.version !== 1 || !Array.isArray(config.presets)) return defaultConfiguration();
  const keys = /* @__PURE__ */ new Set();
  for (const row of config.presets) {
    if (!row || typeof row.key !== "string" || !row.key || keys.has(row.key)) return defaultConfiguration();
    keys.add(row.key);
    if (row.defaultId) {
      const original = defaultConfiguration().presets.find((preset) => preset.key === row.defaultId);
      if (!original || row.key !== original.key || row.minutes !== original.minutes) return defaultConfiguration();
    } else if (!row.key.startsWith("custom:") || !Number.isInteger(row.minutes) || row.minutes <= 0 || row.minutes > 2147483647) return defaultConfiguration();
  }
  return {
    version: 1,
    presets: config.presets.map((row) => ({
      key: row.key,
      minutes: row.minutes,
      ...row.defaultId ? {
        defaultId: row.defaultId
      } : {}
    }))
  };
}
function durationMinutes(duration, unit) {
  const minutes = duration * (unit === "hours" ? 60 : 1);
  if (typeof duration !== "number" || !Number.isFinite(minutes) || !Number.isInteger(minutes) || minutes <= 0 || minutes > 2147483647 || !["minutes", "hours"].includes(unit)) throw new Error("Enter a positive duration in whole minutes (for example, 25 minutes or 1.5 hours).");
  return minutes;
}
function label(minutes) {
  if (!minutes) return "End of track / episode";
  const hours = Math.floor(minutes / 60), rest = minutes % 60;
  if (!hours) return `${minutes} minute${minutes === 1 ? "" : "s"}`;
  return `${hours} hour${hours === 1 ? "" : "s"}${rest ? ` ${rest} minute${rest === 1 ? "" : "s"}` : ""}`;
}
var TimerManager = class {
  constructor(api, storage, open, createId) {
    __publicField(this, "config");
    __publicField(this, "ids", /* @__PURE__ */ new Map());
    __publicField(this, "revision", 0);
    this.api = api;
    this.storage = storage;
    this.open = open;
    this.createId = createId;
    this.config = readConfiguration(storage.get(STORAGE_KEY));
    this.apply(this.config);
  }
  apply(config) {
    this.api.reset();
    this.ids.clear();
    const visibleDefaults = new Set(this.api.list().filter((row) => !row.scriptId).map((row) => row.id));
    for (const preset of defaultConfiguration().presets) {
      if (!config.presets.some((row) => row.defaultId === preset.defaultId) && visibleDefaults.has(preset.key)) this.api.remove(preset.key);
    }
    for (const preset of config.presets) {
      if (preset.defaultId) {
        if (visibleDefaults.has(preset.defaultId)) this.ids.set(preset.key, preset.defaultId);
      } else this.ids.set(preset.key, this.api.add(preset.minutes).id);
    }
    let before;
    for (const preset of [...config.presets].reverse()) {
      const id = this.ids.get(preset.key);
      if (id) {
        this.api.move(id, before);
        before = id;
      }
    }
    const button = this.api.addButton("Manage timers", this.open);
    this.api.move(button.id, before);
  }
  snapshot() {
    return {
      revision: this.revision,
      rows: this.config.presets.map((row) => ({
        key: row.key,
        label: label(row.minutes),
        available: this.ids.has(row.key)
      }))
    };
  }
  handle(request) {
    if (!request || typeof request.requestId !== "string") throw new Error("Invalid timer request.");
    if (request.revision !== this.revision) throw new Error("The timer list changed. Please try again.");
    if (request.type === "submit") {
      const minutes = durationMinutes(request.duration, request.unit);
      if (typeof request.save !== "boolean") throw new Error("Choose whether to save this timer.");
      if (!request.save) {
        this.api.start(request.duration, request.unit);
        return {
          ...this.snapshot(),
          requestId: request.requestId,
          started: true,
          minutes
        };
      }
      if (this.config.presets.some((row) => row.minutes === minutes && minutes > 0)) throw new Error("That duration is already in your timer list.");
      this.commit({
        version: 1,
        presets: [...this.config.presets, {
          key: `custom:${this.createId()}`,
          minutes
        }]
      });
      return {
        ...this.snapshot(),
        requestId: request.requestId,
        saved: true
      };
    }
    if (request.type === "remove") {
      if (!this.config.presets.some((row) => row.key === request.key)) throw new Error("This timer is no longer in the list.");
      this.commit({
        version: 1,
        presets: this.config.presets.filter((row) => row.key !== request.key)
      });
    } else if (request.type === "move") {
      const order = request.order;
      if (!Array.isArray(order) || order.length !== this.config.presets.length || new Set(order).size !== order.length || order.some((key) => !this.config.presets.some((row) => row.key === key))) throw new Error("The timer order is invalid.");
      this.commit({
        version: 1,
        presets: order.map((key) => this.config.presets.find((row) => row.key === key))
      });
    } else throw new Error("Unknown timer action.");
    return {
      ...this.snapshot(),
      requestId: request.requestId
    };
  }
  commit(next) {
    const previous = this.config;
    try {
      this.apply(next);
      this.storage.set(STORAGE_KEY, next);
      this.config = next;
      this.revision++;
    } catch (error) {
      this.apply(previous);
      throw error;
    }
  }
};

// src/index.ts
var timers = import_spotifyplus.SpotifyPlus.Platform.SleepTimer;
var manager;
manager = new TimerManager(timers, import_spotifyplus.SpotifyPlus.Platform.Storage, async () => {
  try {
    await import_spotifyplus.SpotifyPlus.Events.emit("sleepTimers.open", manager.snapshot());
  } catch (error) {
    import_spotifyplus.SpotifyPlus.error("Could not open timer manager", error);
    import_spotifyplus.SpotifyPlus.toast("Could not open the timer manager.");
  }
}, () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2)}`);
import_spotifyplus.SpotifyPlus.Events.on("sleepTimers.request", async (request) => {
  try {
    const reply = manager.handle(request);
    await import_spotifyplus.SpotifyPlus.Events.emit("sleepTimers.reply", reply);
    if ("started" in reply && reply.started) import_spotifyplus.SpotifyPlus.toast(`Sleep timer set for ${label(reply.minutes)}.`);
  } catch (error) {
    await import_spotifyplus.SpotifyPlus.Events.emit("sleepTimers.reply", {
      ...manager.snapshot(),
      requestId: request?.requestId,
      error: error instanceof Error ? error.message : "Unable to update timers."
    });
  }
});
