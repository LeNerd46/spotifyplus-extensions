# Sleep Timer Manager

Adds **Manage timers** at the top of Spotify's sleep timer menu. The manager uses Spotify's
native bottom sheet with a custom Java list: touch and hold a row or its grip to drag it, scroll
near either edge while dragging, or use the accessibility actions **Move earlier / Move later**.
Tap **Remove** to delete a preset. Defaults and the end-of-content option can also be removed.
Ordering and removals are saved automatically and restored when the extension loads again.

**Add sleep timer** opens a second sheet with a duration field, Minutes / Hours, and **Save as
preset**. With saving enabled, **Save timer** adds the preset to the menu without starting it.
With saving disabled, **Start once** starts Spotify's native timer immediately without changing
the preset list. Cancel, Back, or tapping outside discards an unsubmitted form. Fractional hours
such as 1.5 are supported; the duration must resolve to a positive whole number of minutes.
Duplicate saved durations are rejected. Other extensions' presets are preserved.

Requires the local Spotify Plus host with `Platform.SleepTimer` including `start()` and native
extension events. The Spotify bottom sheet/controller mappings target **9.1.82.2160**. This
extension uses the same native dialog backing the React BottomSheet; it builds the two complete
sheets in Java so it can open independently of a mounted React page. No playback polling or JS
timeout is used for one-time timers. Spotify's device restrictions still apply.

## Build

From the SpotifyPlus repository, build the current SDK and host:

```powershell
.\gradlew.bat :spotifyplus-sdk:assembleRelease :app:assembleDebug
```

From this extension directory:

```powershell
npm install
npm run typecheck
npm test
npm run build
```

The native build copies the local SDK AAR, compiles the Java plugin, and writes `native.apk`.
The extension build bundles `src/index.ts`, includes the native APK, and writes a distribution
zip into `dist`. The zip contains `manifest.json`, `index.js`, `native.apk`, and this README at
its root. Extract it into your installed extension directory, or run `npm run dev` for the usual
development connection. The native APK is a plugin payload, not a standalone Android app.
`native/local.properties` identifies your Android SDK and is not committed.

State is stored under `sleep-timer-presets-v1` in extension storage. Stable configuration keys
are independent of the temporary native menu IDs recreated on load. A failed storage write
restores the prior menu state. Requests carry a revision so stale drag/delete operations cannot
overwrite a newer configuration. Unloading the plugin dismisses its sheets and releases drag
handlers and event listeners; the host cleans up the menu edits.

Regression tests cover persistence, ordering, removal, hours, one-time timers, duplicate and
invalid input, stale edits, empty lists, foreign rows, and rollback. Builds and automated tests
do not verify native drag gestures or Spotify hook compatibility on-device.
